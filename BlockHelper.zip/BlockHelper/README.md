# Block Helper
Оверлей-подсказчик для Block Blast (поле 8x8). Без ИИ: распознавание по цвету + перебор ходов.
Сборка: залей папку в GitHub-репозиторий (ветка main) -> Actions -> Build APK -> Artifacts -> BlockHelper-apk.
