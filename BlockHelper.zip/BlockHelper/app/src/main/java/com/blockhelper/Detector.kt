package com.blockhelper

import android.graphics.RectF
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class Frame(val w: Int, val h: Int, val px: IntArray)
class BoardRect(val left: Float, val top: Float, val size: Float)
class Reading(val board: Long, val pieces: Array<Shape?>, val tray: Array<RectF?>)

object Detector {
    private fun lum(p: Int) = ((p and 0xFF) * 299 + ((p shr 8) and 0xFF) * 587 + ((p shr 16) and 0xFF) * 114) / 1000

    private fun fill(p: Int): Boolean {
        val r = p and 0xFF; val g = (p shr 8) and 0xFF; val b = (p shr 16) and 0xFF
        val mx = max(r, max(g, b)); val mn = min(r, min(g, b))
        return mx >= 140 && (mx - mn) * 10 >= 3 * mx
    }

    /** Авто-поиск поля 8x8: самая длинная горизонтальная полоса, где есть широкие границы/клетки. */
    fun findBoard(f: Frame): BoardRect? {
        val w = f.w; val h = f.h
        val first = IntArray(h) { -1 }
        val last = IntArray(h) { -1 }
        for (y in 0 until h step 2) {
            val base = y * w
            var x = 0
            while (x + 3 < w) {
                if (abs(lum(f.px[base + x]) - lum(f.px[base + x + 3])) > 10) {
                    if (first[y] < 0) first[y] = x
                    last[y] = x + 3
                }
                x += 3
            }
        }
        val runs = ArrayList<IntArray>()
        var s = -1; var e = -1; var gap = 0
        var y = 0
        while (y < h) {
            val wide = first[y] >= 0 && (last[y] - first[y]) >= 0.6f * w
            if (wide) { if (s < 0) s = y; e = y; gap = 0 }
            else if (s >= 0) { gap += 2; if (gap > 14) { runs.add(intArrayOf(s, e)); s = -1 } }
            y += 2
        }
        if (s >= 0) runs.add(intArrayOf(s, e))
        val run = runs.maxByOrNull { it[1] - it[0] } ?: return null
        val l = ArrayList<Int>(); val r = ArrayList<Int>()
        var yy = run[0]
        while (yy <= run[1]) { if (first[yy] >= 0) { l.add(first[yy]); r.add(last[yy]) }; yy += 2 }
        if (l.isEmpty()) return null
        l.sort(); r.sort()
        val left = l[l.size / 2].toFloat(); val right = r[r.size / 2].toFloat()
        val bw = right - left
        val bh = (run[1] - run[0]).toFloat()
        if (bw < 0.5f * w || bw > w) return null
        val cx = (left + right) / 2f
        val size: Float; val cy: Float
        if (abs(bh - bw) <= 0.15f * bw) { size = (bw + bh) / 2f; cy = (run[0] + run[1]) / 2f }
        else if (bh > bw) { size = bw; cy = run[0] + size / 2f }
        else return null
        return BoardRect(cx - size / 2f, cy - size / 2f, size)
    }

    fun read(f: Frame, br: BoardRect, ratio: Float): Reading {
        val cell = br.size / 8f
        val v = DoubleArray(64); val sat = DoubleArray(64)
        for (i in 0 until 64) {
            val cx = br.left + (i % 8 + 0.5f) * cell
            val cy = br.top + (i / 8 + 0.5f) * cell
            var r = 0; var g = 0; var b = 0; var n = 0
            for (dy in -2..2) for (dx in -2..2) {
                val x = (cx + dx * cell * 0.08f).toInt(); val y = (cy + dy * cell * 0.08f).toInt()
                if (x < 0 || y < 0 || x >= f.w || y >= f.h) continue
                val p = f.px[y * f.w + x]
                r += p and 0xFF; g += (p shr 8) and 0xFF; b += (p shr 16) and 0xFF; n++
            }
            if (n == 0) continue
            val mx = max(r, max(g, b)).toDouble(); val mn = min(r, min(g, b)).toDouble()
            v[i] = mx / (n * 255.0)
            sat[i] = if (mx > 0) (mx - mn) / mx else 0.0
        }
        val thr = max(0.55, v.min() + 0.25)
        var board = 0L
        for (i in 0 until 64) if (v[i] >= thr && sat[i] >= 0.25) board = board or (1L shl i)

        val pieces = arrayOfNulls<Shape>(3)
        val tray = arrayOfNulls<RectF>(3)
        val y0 = (br.top + br.size + cell * 0.1f).toInt().coerceIn(0, f.h - 1)
        val y1 = min(f.h - 1, (br.top + br.size + br.size * 0.62f).toInt())
        val x0 = max(0, (br.left - cell * 0.3f).toInt())
        val x1 = min(f.w - 1, (br.left + br.size + cell * 0.3f).toInt())
        if (y0 >= y1 || x0 >= x1) return Reading(board, pieces, tray)

        val colHas = BooleanArray(f.w)
        for (y in y0..y1 step 2) for (x in x0..x1 step 2) if (fill(f.px[y * f.w + x])) colHas[x] = true
        // группы столбцов = отдельные фигуры
        val groups = ArrayList<IntArray>()
        var gs = -1; var ge = -1
        val gapMax = (cell * 0.35f).toInt()
        for (x in x0..x1) {
            if (colHas[x]) { if (gs < 0) gs = x; ge = x }
            else if (gs >= 0 && x - ge > gapMax) { groups.add(intArrayOf(gs, ge)); gs = -1 }
        }
        if (gs >= 0) groups.add(intArrayOf(gs, ge))

        class G(val gx0: Int, val gx1: Int, val ty0: Int, val ty1: Int, val slot: Int)
        val gl = ArrayList<G>()
        for (g in groups) {
            if (g[1] - g[0] < cell * 0.25f) continue
            var minY = Int.MAX_VALUE; var maxY = -1
            for (y in y0..y1 step 2) for (x in g[0]..g[1] step 2) if (fill(f.px[y * f.w + x])) { if (y < minY) minY = y; if (y > maxY) maxY = y }
            if (maxY < 0 || maxY - minY < cell * 0.25f) continue
            val slot = (((g[0] + g[1]) / 2f - br.left) / (br.size / 3f)).toInt().coerceIn(0, 2)
            if (gl.any { it.slot == slot }) continue
            gl.add(G(g[0], g[1], minY, maxY, slot))
        }
        if (gl.isEmpty()) return Reading(board, pieces, tray)

        val minDim = gl.minOf { min(it.gx1 - it.gx0 + 1, it.ty1 - it.ty0 + 1) }.toFloat()
        val k = max(1, (minDim / (ratio * cell)).roundToInt())
        val s = minDim / k
        for (g in gl) {
            val gw = (g.gx1 - g.gx0 + 1).toFloat(); val gh = (g.ty1 - g.ty0 + 1).toFloat()
            val nw = max(1, (gw / s).roundToInt()).coerceAtMost(6)
            val nh = max(1, (gh / s).roundToInt()).coerceAtMost(6)
            val cells = ArrayList<IntArray>()
            for (j in 0 until nh) for (i in 0 until nw) {
                val cx = g.gx0 + (i + 0.5f) * gw / nw
                val cy = g.ty0 + (j + 0.5f) * gh / nh
                var hit = 0
                for (dy in -1..1) for (dx in -1..1) {
                    val x = (cx + dx * s * 0.2f).toInt().coerceIn(0, f.w - 1)
                    val y = (cy + dy * s * 0.2f).toInt().coerceIn(0, f.h - 1)
                    if (fill(f.px[y * f.w + x])) hit++
                }
                if (hit >= 5) cells.add(intArrayOf(j, i))
            }
            if (cells.isEmpty()) continue
            val mr = cells.minOf { it[0] }; val mc = cells.minOf { it[1] }
            pieces[g.slot] = Shape(cells.map { intArrayOf(it[0] - mr, it[1] - mc) })
            tray[g.slot] = RectF(g.gx0.toFloat(), g.ty0.toFloat(), g.gx1.toFloat(), g.ty1.toFloat())
        }
        return Reading(board, pieces, tray)
    }
}
