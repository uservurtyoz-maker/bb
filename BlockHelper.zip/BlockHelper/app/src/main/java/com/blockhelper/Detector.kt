package com.blockhelper

import android.graphics.RectF
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class Frame(val w: Int, val h: Int, val px: IntArray)
class BoardRect(val left: Float, val top: Float, val size: Float)
class Reading(val board: Long, val pieces: Array<Shape?>, val tray: Array<RectF?>, val colors: IntArray)

object Detector {
    private fun lum(p: Int) = ((p and 0xFF) * 299 + ((p shr 8) and 0xFF) * 587 + ((p shr 16) and 0xFF) * 114) / 1000

    /** Пиксель отличается от фона этой же строки (фон = смесь цветов у левого и правого края экрана). */
    private fun pieceAt(f: Frame, x: Int, y: Int): Boolean {
        val m = max(4, (f.w * 0.015f).toInt())
        val row = y * f.w
        val p = f.px[row + x]
        val l = f.px[row + m]
        val r = f.px[row + f.w - 1 - m]
        val w1 = f.w - 1
        val br = (l and 0xFF) + (((r and 0xFF) - (l and 0xFF)) * x) / w1
        val bg = ((l shr 8) and 0xFF) + ((((r shr 8) and 0xFF) - ((l shr 8) and 0xFF)) * x) / w1
        val bb = ((l shr 16) and 0xFF) + ((((r shr 16) and 0xFF) - ((l shr 16) and 0xFF)) * x) / w1
        val d = max(abs((p and 0xFF) - br), max(abs(((p shr 8) and 0xFF) - bg), abs(((p shr 16) and 0xFF) - bb)))
        return d >= 45
    }

    private fun fitRect(left: Float, right: Float, top: Float, bottom: Float, w: Int): BoardRect? {
        val bw = right - left
        val bh = bottom - top
        if (bw < 0.5f * w || bw > w) return null
        val cx = (left + right) / 2f
        val size: Float; val cy: Float
        if (abs(bh - bw) <= 0.15f * bw) { size = (bw + bh) / 2f; cy = (top + bottom) / 2f }
        else if (bh > bw) { size = bw; cy = top + size / 2f }
        else return null
        return BoardRect(cx - size / 2f, cy - size / 2f, size)
    }

    /** Поле: сначала по «широкой полосе, отличающейся от фона», запасной вариант по границам клеток. */
    fun findBoard(f: Frame): BoardRect? = findByBg(f) ?: findByEdges(f)

    private fun findByBg(f: Frame): BoardRect? {
        val w = f.w; val h = f.h
        val xa = (w * 0.03f).toInt(); val xb = (w * 0.97f).toInt()
        val ok = BooleanArray(h)
        for (y in 0 until h step 2) {
            var c = 0; var t = 0; var x = xa
            while (x < xb) { if (pieceAt(f, x, y)) c++; t++; x += 4 }
            ok[y] = c >= 0.75f * t
        }
        var s = -1; var e = -1; var gap = 0; var bs = -1; var be = -1
        var y = 0
        while (y < h) {
            if (ok[y]) { if (s < 0) s = y; e = y; gap = 0 }
            else if (s >= 0) { gap += 2; if (gap > 12) { if (e - s > be - bs) { bs = s; be = e }; s = -1 } }
            y += 2
        }
        if (s >= 0 && e - s > be - bs) { bs = s; be = e }
        if (bs < 0 || be - bs < 0.45f * w) return null
        var left = -1; var right = -1
        for (x in 0 until w step 2) {
            var c = 0; var t = 0; var yy = bs
            while (yy <= be) { if (pieceAt(f, x, yy)) c++; t++; yy += 4 }
            if (c >= 0.7f * t) { if (left < 0) left = x; right = x }
        }
        if (left < 0) return null
        return fitRect(left.toFloat(), right.toFloat(), bs.toFloat(), be.toFloat(), w)
    }

    private fun findByEdges(f: Frame): BoardRect? {
        val w = f.w; val h = f.h
        val first = IntArray(h) { -1 }
        val last = IntArray(h) { -1 }
        for (y in 0 until h step 2) {
            val base = y * w
            var x = 0
            while (x + 3 < w) {
                if (abs(lum(f.px[base + x]) - lum(f.px[base + x + 3])) > 10) {
                    if (first[y] < 0) first[y] = x
                    last[y] = x + 3
                }
                x += 3
            }
        }
        val runs = ArrayList<IntArray>()
        var s = -1; var e = -1; var gap = 0
        var y = 0
        while (y < h) {
            val wide = first[y] >= 0 && (last[y] - first[y]) >= 0.6f * w
            if (wide) { if (s < 0) s = y; e = y; gap = 0 }
            else if (s >= 0) { gap += 2; if (gap > 14) { runs.add(intArrayOf(s, e)); s = -1 } }
            y += 2
        }
        if (s >= 0) runs.add(intArrayOf(s, e))
        val run = runs.maxByOrNull { it[1] - it[0] } ?: return null
        val l = ArrayList<Int>(); val r = ArrayList<Int>()
        var yy = run[0]
        while (yy <= run[1]) { if (first[yy] >= 0) { l.add(first[yy]); r.add(last[yy]) }; yy += 2 }
        if (l.isEmpty()) return null
        l.sort(); r.sort()
        return fitRect(l[l.size / 2].toFloat(), r[r.size / 2].toFloat(), run[0].toFloat(), run[1].toFloat(), w)
    }

    fun read(f: Frame, br: BoardRect, ratio: Float): Reading {
        val cell = br.size / 8f
        val ar = DoubleArray(64); val ag = DoubleArray(64); val ab = DoubleArray(64)
        for (i in 0 until 64) {
            val cx = br.left + (i % 8 + 0.5f) * cell
            val cy = br.top + (i / 8 + 0.5f) * cell
            var r = 0; var g = 0; var b = 0; var n = 0
            for (dy in -2..2) for (dx in -2..2) {
                val x = (cx + dx * cell * 0.08f).toInt(); val y = (cy + dy * cell * 0.08f).toInt()
                if (x < 0 || y < 0 || x >= f.w || y >= f.h) continue
                val p = f.px[y * f.w + x]
                r += p and 0xFF; g += (p shr 8) and 0xFF; b += (p shr 16) and 0xFF; n++
            }
            if (n == 0) continue
            ar[i] = r / n.toDouble(); ag[i] = g / n.toDouble(); ab[i] = b / n.toDouble()
        }
        // эталон пустой клетки = среднее по самым тёмным клеткам; занято = цвет заметно отличается
        val dark = (0 until 64).sortedBy { ar[it] + ag[it] + ab[it] }.take(8)
        val rr = dark.map { ar[it] }.average(); val rg = dark.map { ag[it] }.average(); val rb = dark.map { ab[it] }.average()
        var board = 0L
        for (i in 0 until 64) {
            val d = max(abs(ar[i] - rr), max(abs(ag[i] - rg), abs(ab[i] - rb)))
            if (d >= 40.0) board = board or (1L shl i)
        }

        val pieces = arrayOfNulls<Shape>(3)
        val tray = arrayOfNulls<RectF>(3)
        val colors = IntArray(3)
        val y0 = (br.top + br.size + cell * 0.25f).toInt().coerceIn(0, f.h - 1)
        val y1 = min((f.h * 0.96f).toInt(), (br.top + br.size + br.size * 0.95f).toInt())
        val x0 = max(0, (br.left - cell * 0.3f).toInt())
        val x1 = min(f.w - 1, (br.left + br.size + cell * 0.3f).toInt())
        if (y0 >= y1 || x0 >= x1 || f.w < 60) return Reading(board, pieces, tray, colors)

        val colHas = BooleanArray(f.w)
        for (y in y0..y1 step 2) for (x in x0..x1 step 2) if (pieceAt(f, x, y)) colHas[x] = true
        val groups = ArrayList<IntArray>()
        var gs = -1; var ge = -1
        val gapMax = (cell * 0.35f).toInt()
        for (x in x0..x1) {
            if (colHas[x]) { if (gs < 0) gs = x; ge = x }
            else if (gs >= 0 && x - ge > gapMax) { groups.add(intArrayOf(gs, ge)); gs = -1 }
        }
        if (gs >= 0) groups.add(intArrayOf(gs, ge))

        class G(val gx0: Int, val gx1: Int, val ty0: Int, val ty1: Int, val slot: Int)
        val gl = ArrayList<G>()
        val maxDim = br.size * 0.55f
        for (g in groups) {
            if (g[1] - g[0] < cell * 0.25f || g[1] - g[0] > maxDim) continue
            var minY = Int.MAX_VALUE; var maxY = -1
            for (y in y0..y1 step 2) for (x in g[0]..g[1] step 2) if (pieceAt(f, x, y)) { if (y < minY) minY = y; if (y > maxY) maxY = y }
            if (maxY < 0 || maxY - minY < cell * 0.25f || maxY - minY > maxDim) continue
            val slot = (((g[0] + g[1]) / 2f - br.left) / (br.size / 3f)).toInt().coerceIn(0, 2)
            if (gl.any { it.slot == slot }) continue
            gl.add(G(g[0], g[1], minY, maxY, slot))
        }
        if (gl.isEmpty()) return Reading(board, pieces, tray, colors)

        // размер клетки в лотке: известное отношение к клетке поля, иначе по минимальному размеру фигуры
        val s0 = ratio * cell
        fun frac(x: Float): Float { val q = x / s0; return abs(q - q.roundToInt()) }
        val err = gl.maxOf { max(frac((it.gx1 - it.gx0 + 1).toFloat()), frac((it.ty1 - it.ty0 + 1).toFloat())) }
        val s = if (err <= 0.3f) s0 else {
            val minDim = gl.minOf { min(it.gx1 - it.gx0 + 1, it.ty1 - it.ty0 + 1) }.toFloat()
            minDim / max(1, (minDim / s0).roundToInt())
        }

        for (g in gl) {
            val gw = (g.gx1 - g.gx0 + 1).toFloat(); val gh = (g.ty1 - g.ty0 + 1).toFloat()
            val nw = max(1, (gw / s).roundToInt()).coerceAtMost(6)
            val nh = max(1, (gh / s).roundToInt()).coerceAtMost(6)
            val cells = ArrayList<IntArray>()
            for (j in 0 until nh) for (i in 0 until nw) {
                val cx = g.gx0 + (i + 0.5f) * gw / nw
                val cy = g.ty0 + (j + 0.5f) * gh / nh
                var hit = 0
                for (dy in -1..1) for (dx in -1..1) {
                    val x = (cx + dx * s * 0.2f).toInt().coerceIn(0, f.w - 1)
                    val y = (cy + dy * s * 0.2f).toInt().coerceIn(0, f.h - 1)
                    if (pieceAt(f, x, y)) hit++
                }
                if (hit >= 5) {
                    cells.add(intArrayOf(j, i))
                    if (colors[g.slot] == 0) {
                        val p = f.px[cy.toInt().coerceIn(0, f.h - 1) * f.w + cx.toInt().coerceIn(0, f.w - 1)]
                        colors[g.slot] = (0xFF shl 24) or ((p and 0xFF) shl 16) or (((p shr 8) and 0xFF) shl 8) or ((p shr 16) and 0xFF)
                    }
                }
            }
            if (cells.isEmpty()) continue
            val mr = cells.minOf { it[0] }; val mc = cells.minOf { it[1] }
            pieces[g.slot] = Shape(cells.map { intArrayOf(it[0] - mr, it[1] - mc) })
            tray[g.slot] = RectF(g.gx0.toFloat(), g.ty0.toFloat(), g.gx1.toFloat(), g.ty1.toFloat())
        }
        return Reading(board, pieces, tray, colors)
    }

    /** Отпечаток прямоугольника фигуры: сетка 8x8 точек, бит = фигура. */
    fun sig(f: Frame, r: RectF): Long {
        var s = 0L
        for (j in 0 until 8) for (i in 0 until 8) {
            val x = (r.left + (i + 0.5f) * (r.width() + 1f) / 8f).toInt().coerceIn(0, f.w - 1)
            val y = (r.top + (j + 0.5f) * (r.height() + 1f) / 8f).toInt().coerceIn(0, f.h - 1)
            if (pieceAt(f, x, y)) s = s or (1L shl (j * 8 + i))
        }
        return s
    }

    /** 0 = слот пуст, 1 = та же фигура, 2 = там что-то другое (новая фигура или «призрак» перетаскивания). */
    fun slotStates(f: Frame, rects: Array<RectF?>, sigs: LongArray): IntArray = IntArray(3) { i ->
        val r = rects[i]
        if (r == null) 0 else {
            val s = sig(f, r)
            if (s == 0L) 0 else if (java.lang.Long.bitCount(s xor sigs[i]) <= 8) 1 else 2
        }
    }
}
