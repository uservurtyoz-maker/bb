package com.blockhelper

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import java.nio.ByteOrder
import kotlin.math.min
import kotlin.math.roundToInt

/** Прозрачный слой: каждая фигура своим цветом (как в лотке), с общим контуром и номером хода. */
class HintsView(ctx: Context) : View(ctx) {
    var board: BoardRect? = null
    var plan: Plan? = null
    var present = BooleanArray(3) { true }
    var held = -1
    var k = 1f
    var tray: Array<RectF?> = arrayOfNulls(3)
    var colors = IntArray(3)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textAlign = Paint.Align.CENTER; isFakeBoldText = true
        setShadowLayer(5f, 0f, 0f, Color.BLACK)
    }
    private val defc = intArrayOf(0xFFFF4D4D.toInt(), 0xFF3DA9FF.toInt(), 0xFF3DDC84.toInt())

    private fun has(m: Long, i: Int) = i in 0..63 && ((m ushr i) and 1L) == 1L

    private fun contour(mask: Long, b: BoardRect, cell: Float): Path {
        val p = Path()
        for (i in 0 until 64) {
            if (!has(mask, i)) continue
            val r = i / 8; val c = i % 8
            val x = b.left + c * cell; val y = b.top + r * cell
            if (r == 0 || !has(mask, i - 8)) { p.moveTo(x, y); p.lineTo(x + cell, y) }
            if (r == 7 || !has(mask, i + 8)) { p.moveTo(x, y + cell); p.lineTo(x + cell, y + cell) }
            if (c == 0 || !has(mask, i - 1)) { p.moveTo(x, y); p.lineTo(x, y + cell) }
            if (c == 7 || !has(mask, i + 1)) { p.moveTo(x + cell, y); p.lineTo(x + cell, y + cell) }
        }
        return p
    }

    private fun cells(c: Canvas, mask: Long, b: BoardRect, cell: Float, color: Int) {
        fill.color = color
        for (i in 0 until 64) {
            if (!has(mask, i)) continue
            val x = b.left + (i % 8) * cell; val y = b.top + (i / 8) * cell
            c.drawRoundRect(RectF(x + 3, y + 3, x + cell - 3, y + cell - 3), 8f, 8f, fill)
        }
    }

    override fun onDraw(c: Canvas) {
        val b = board ?: return
        val pl = plan ?: return
        val loc = IntArray(2); getLocationOnScreen(loc)
        c.translate(-loc[0].toFloat(), -loc[1].toFloat())
        c.scale(k, k)
        val cell = b.size / 8f
        val next = pl.moves.indexOfFirst { present[it.slot] }
        txt.textSize = cell * 0.42f
        for ((i, m) in pl.moves.withIndex()) {
            val isPresent = present[m.slot]
            if (!isPresent && m.slot != held) continue
            val strong = i == next
            val col = if (colors[m.slot] != 0) colors[m.slot] else defc[i % 3]
            if (strong && m.burn != 0L) {
                cells(c, m.burn, b, cell, 0x44FFFFFF)
                line.color = Color.WHITE; line.strokeWidth = 3f
                c.drawPath(contour(m.burn, b, cell), line)
            }
            cells(c, m.mask, b, cell, (col and 0xFFFFFF) or (80 shl 24))
            val path = contour(m.mask, b, cell)
            line.color = Color.WHITE; line.strokeWidth = if (strong) 12f else if (isPresent) 7f else 5f
            c.drawPath(path, line)
            line.color = col; line.strokeWidth = if (strong) 7f else if (isPresent) 4f else 3f
            c.drawPath(path, line)
            var sr = 0f; var sc = 0f; var n = 0
            for (j in 0 until 64) if (has(m.mask, j)) { sr += j / 8; sc += j % 8; n++ }
            if (n > 0) {
                val cx = b.left + (sc / n + 0.5f) * cell; val cy = b.top + (sr / n + 0.5f) * cell
                fill.color = 0x99000000.toInt()
                c.drawCircle(cx, cy, cell * 0.28f, fill)
                c.drawText("${i + 1}", cx, cy + txt.textSize / 3, txt)
            }
            if (isPresent) tray[m.slot]?.let { t ->
                var cy = t.top - cell * 0.35f
                if (cy < cell * 0.3f) cy = t.bottom + cell * 0.4f
                val rad = cell * (if (strong) 0.34f else 0.26f)
                fill.color = Color.WHITE
                c.drawCircle(t.centerX(), cy, rad + 4f, fill)
                fill.color = col
                c.drawCircle(t.centerX(), cy, rad, fill)
                c.drawText("${i + 1}", t.centerX(), cy + txt.textSize / 3, txt)
            }
        }
    }
}

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private val ui = Handler(Looper.getMainLooper())
    private var thread: HandlerThread? = null
    private var bg: Handler? = null
    private var projection: MediaProjection? = null
    @Volatile private var reader: ImageReader? = null
    private var vd: VirtualDisplay? = null
    private var hints: HintsView? = null
    private var panel: View? = null
    private var toggle: TextView? = null
    private var status: TextView? = null
    private var beat: View? = null
    private var flip = false
    @Volatile private var enabled = false

    // размеры экрана и захвата (захват всегда ужимается до 720 px по ширине: одинаково на любых телефонах)
    private var realW = 0
    private var realH = 0
    private var capW = 0
    private var capH = 0
    private var kScale = 1f
    private var pix: IntArray? = null
    private var frame: Frame? = null

    private var board: BoardRect? = null
    private var lastKey: String? = null
    private var pendingKey: String? = null
    private var idle = 0
    private var hasPlan = false
    private var plan: Plan? = null
    private var savedPlan: Plan? = null
    private var readTicks = 0
    private var trig = 0
    private var sawAbsent = false
    private var lastVacated = -1
    private var prevSt = IntArray(3) { 1 }
    private var planRects: Array<RectF?> = arrayOfNulls(3)
    private var planSigs = LongArray(3)

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) { stopSelf(); return START_NOT_STICKY }
        if (hints != null) return START_NOT_STICKY
        startFg()
        val code = intent.getIntExtra("code", 0)
        @Suppress("DEPRECATION")
        val data = intent.getParcelableExtra<Intent>("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val t = HandlerThread("bh"); t.start(); thread = t; bg = Handler(t.looper)
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val p = mpm.getMediaProjection(code, data)
        projection = p
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { ui.post { stopSelf() } }
        }, ui)
        ensureCapture()
        buildUi()
        hints?.k = kScale
        return START_NOT_STICKY
    }

    /** Подстраивается под экран: размер, поворот, любое разрешение. */
    @Synchronized
    private fun ensureCapture() {
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(dm)
        val rw = dm.widthPixels; val rh = dm.heightPixels
        if (rw == realW && rh == realH && reader != null) return
        realW = rw; realH = rh
        capW = min(rw, 720)
        capH = (rh * capW.toFloat() / rw).roundToInt()
        kScale = rw.toFloat() / capW
        val old = reader
        val nr = ImageReader.newInstance(capW, capH, PixelFormat.RGBA_8888, 2)
        reader = nr
        val p = projection ?: return
        if (vd == null) {
            vd = p.createVirtualDisplay("bh", capW, capH, dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, null, null, null)
        } else vd?.resize(capW, capH, dm.densityDpi)
        if (enabled) vd?.surface = nr.surface
        try { old?.close() } catch (e: Exception) {}
        pix = null; frame = null
        resetState()
        hints?.k = kScale
    }

    private fun resetState() {
        board = null; lastKey = null; pendingKey = null; idle = 0
        hasPlan = false; plan = null; savedPlan = null; readTicks = 0
        trig = 0; sawAbsent = false; lastVacated = -1
        ui.post { hints?.plan = null; hints?.invalidate() }
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("ov", "Overlay", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "ov")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("Block Helper")
            .setContentText("Оверлей работает")
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun tv(t: String, size: Float = 15f) = TextView(this).apply {
        text = t; setTextColor(Color.WHITE); textSize = size
        setPadding(dp(10), dp(6), dp(10), dp(6)); gravity = Gravity.CENTER
    }

    private fun pill(color: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(14).toFloat() }

    private fun buildUi() {
        val hv = HintsView(this); hints = hv
        val lp = WindowManager.LayoutParams(
            -1, -1, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        if (Build.VERSION.SDK_INT >= 28)
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        wm.addView(hv, lp)

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.background = pill(0xDD14141C.toInt())
        val grip = tv("≡", 20f)
        val tg = tv("ВЫКЛ"); tg.background = pill(0xFF8A2B2B.toInt()); toggle = tg
        val st = tv("—", 12f); status = st
        val close = tv("✕", 16f)
        val bt = View(this); beat = bt
        for (v in listOf(grip, tg, st, close)) row.addView(v)
        row.addView(bt, LinearLayout.LayoutParams(dp(3), dp(3)))
        panel = row

        val plp = WindowManager.LayoutParams(
            -2, -2, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        )
        plp.gravity = Gravity.TOP or Gravity.START; plp.x = dp(8); plp.y = dp(60)
        grip.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = plp.x; oy = plp.y }
                    MotionEvent.ACTION_MOVE -> {
                        plp.x = ox + (e.rawX - sx).toInt(); plp.y = oy + (e.rawY - sy).toInt()
                        wm.updateViewLayout(row, plp)
                    }
                }
                return true
            }
        })
        tg.setOnClickListener { setOn(!enabled) }
        close.setOnClickListener { stopSelf() }
        wm.addView(row, plp)
    }

    private fun say(s: String) { ui.post { status?.text = s } }

    private fun setOn(on: Boolean) {
        enabled = on
        toggle?.text = if (on) "ВКЛ" else "ВЫКЛ"
        toggle?.background = pill(if (on) 0xFF1F8A4C.toInt() else 0xFF8A2B2B.toInt())
        val b = bg ?: return
        if (on) {
            vd?.surface = reader?.surface
            b.post { resetState(); frame = null; tick.run() }
        } else {
            b.removeCallbacks(tick)
            vd?.surface = null
            hasPlan = false
            hints?.plan = null; hints?.invalidate()
            say("—")
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!enabled) return
            try { step() } catch (e: Throwable) { say("ошибка") }
            if (enabled) bg?.postDelayed(this, 350)
        }
    }

    private fun grab(rd: ImageReader) {
        val img = rd.acquireLatestImage() ?: return
        try {
            val pl = img.planes[0]
            val buf = pl.buffer.order(ByteOrder.nativeOrder()).asIntBuffer()
            val stride = pl.rowStride / 4
            val w = img.width; val h = img.height
            val arr = pix?.takeIf { it.size == w * h } ?: IntArray(w * h).also { pix = it }
            for (y in 0 until h) { buf.position(y * stride); buf.get(arr, y * w, w) }
            frame = Frame(w, h, arr)
        } finally { img.close() }
    }

    private fun restore(f: Frame) {
        val hv = hints ?: return
        val p = savedPlan ?: return
        plan = p; savedPlan = null; hasPlan = true; trig = 0; sawAbsent = false
        val st = Detector.slotStates(f, planRects, planSigs)
        for (i in 0..2) prevSt[i] = st[i]
        val pr = BooleanArray(3) { st[it] != 0 }
        val held = lastVacated
        ui.post { hv.plan = p; hv.present = pr; hv.held = held; hv.invalidate() }
    }

    private fun step() {
        val hv = hints ?: return
        ensureCapture()
        val rd = reader ?: return
        // «пульс»: крошечное изменение на экране, чтобы захват всегда отдавал свежий кадр
        ui.post {
            flip = !flip
            beat?.setBackgroundColor(if (flip) 0xFF14141C.toInt() else 0xFF17141C.toInt())
        }
        Thread.sleep(130)
        grab(rd)
        val f = frame ?: return
        if (f.w > f.h) { say("портрет!"); return }

        // ---- режим «подсказка показана»: следим только за лотком, без мигания ----
        if (hasPlan) {
            val st = Detector.slotStates(f, planRects, planSigs)
            for (i in 0..2) {
                if (planRects[i] != null && st[i] == 0 && prevSt[i] != 0) { lastVacated = i; sawAbsent = true }
                prevSt[i] = st[i]
            }
            val occ = st.count { it != 0 }
            val chg = st.count { it == 2 }
            val newTray = (occ == 3 && (chg >= 1 || sawAbsent)) || chg >= 2
            trig = if (newTray) trig + 1 else 0
            if (trig >= 2) {
                // похоже на новый набор: прячем подсказку и читаем экран заново (старая сохраняется)
                savedPlan = plan; hasPlan = false; readTicks = 0; trig = 0
                ui.post { hv.plan = null; hv.invalidate() }
                return
            }
            val pr = BooleanArray(3) { st[it] != 0 }
            val held = lastVacated
            ui.post { hv.present = pr; hv.held = held; hv.invalidate() }
            return
        }

        // ---- режим чтения экрана ----
        if (board == null) {
            board = Detector.findBoard(f)
            if (board == null) { say("поле?"); return }
        }
        val br = board!!
        val rdg = Detector.read(f, br, 0.44f)
        val cnt = rdg.pieces.count { it != null }
        if (cnt == 0 && savedPlan == null) {
            say("жду фигуры")
            if (++idle % 12 == 0) board = null
            return
        }
        idle = 0
        if (savedPlan != null) readTicks++
        val desc = rdg.pieces.joinToString(" ") { if (it == null) "–" else "${it.w}x${it.h}" }
        val key = rdg.board.toString() + "|" + rdg.pieces.joinToString("|") { it?.key ?: "-" }
        val isNew = cnt == 3 && key != lastKey
        val isFirst = cnt in 1..2 && lastKey == null
        if (isNew || isFirst) {
            if (key != pendingKey) { pendingKey = key; say(desc); return }
            val t0 = System.currentTimeMillis()
            val np = Solver.solve(rdg.board, rdg.pieces.toList())
            lastKey = key; plan = np; savedPlan = null; hasPlan = np != null
            trig = 0; sawAbsent = false; lastVacated = -1
            for (i in 0..2) prevSt[i] = if (rdg.pieces[i] != null) 1 else 0
            if (np != null) {
                planRects = rdg.tray.copyOf()
                planSigs = LongArray(3) { i -> rdg.tray[i]?.let { Detector.sig(f, it) } ?: 0L }
            }
            val pr = BooleanArray(3) { rdg.pieces[it] != null }
            val ks = kScale
            ui.post {
                hv.board = br; hv.k = ks; hv.colors = rdg.colors; hv.plan = np
                hv.present = pr; hv.held = -1; hv.tray = rdg.tray; hv.invalidate()
            }
            say(if (np == null) "нет ходов" else "ок ${System.currentTimeMillis() - t0}мс")
            return
        }
        if (savedPlan != null && (cnt == 3 || readTicks >= 6)) { restore(f); return }
        say(desc)
    }

    override fun onDestroy() {
        enabled = false
        bg?.removeCallbacksAndMessages(null)
        try { hints?.let { wm.removeView(it) } } catch (e: Exception) {}
        try { panel?.let { wm.removeView(it) } } catch (e: Exception) {}
        try { vd?.release() } catch (e: Exception) {}
        try { reader?.close() } catch (e: Exception) {}
        try { projection?.stop() } catch (e: Exception) {}
        thread?.quitSafely()
        super.onDestroy()
    }
}
