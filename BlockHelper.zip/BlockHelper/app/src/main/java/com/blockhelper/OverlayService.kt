package com.blockhelper

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import java.nio.ByteOrder

/** Прозрачный слой с подсказками. Цвет = порядок хода: 1 красный, 2 синий, 3 зелёный. */
class HintsView(ctx: Context) : View(ctx) {
    var board: BoardRect? = null
    var plan: Plan? = null
    var present = BooleanArray(3) { true }
    var tray: Array<RectF?> = arrayOfNulls(3)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textAlign = Paint.Align.CENTER; isFakeBoldText = true
        setShadowLayer(5f, 0f, 0f, Color.BLACK)
    }
    private val colors = intArrayOf(0xFFFF4D4D.toInt(), 0xFF3DA9FF.toInt(), 0xFF3DDC84.toInt())

    override fun onDraw(c: Canvas) {
        val b = board ?: return
        val pl = plan ?: return
        val loc = IntArray(2); getLocationOnScreen(loc)
        c.translate(-loc[0].toFloat(), -loc[1].toFloat())
        val cell = b.size / 8f
        val next = pl.moves.indexOfFirst { present[it.slot] }
        txt.textSize = cell * 0.45f
        for ((k, m) in pl.moves.withIndex()) {
            if (!present[m.slot]) continue
            val strong = k == next
            val col = colors[k]
            for (i in 0 until 64) {
                val bit = 1L shl i
                val x = b.left + (i % 8) * cell; val y = b.top + (i / 8) * cell
                val r = RectF(x + 2, y + 2, x + cell - 2, y + cell - 2)
                if (strong && (m.burn and bit) != 0L) {
                    fill.color = 0x66FFFFFF
                    c.drawRoundRect(r, 8f, 8f, fill)
                    stroke.color = Color.WHITE; stroke.strokeWidth = 3f
                    c.drawRoundRect(r, 8f, 8f, stroke)
                }
            }
            for (i in 0 until 64) {
                val bit = 1L shl i
                if ((m.mask and bit) == 0L) continue
                val x = b.left + (i % 8) * cell; val y = b.top + (i / 8) * cell
                val r = RectF(x + 2, y + 2, x + cell - 2, y + cell - 2)
                fill.color = (col and 0xFFFFFF) or ((if (strong) 170 else 70) shl 24)
                c.drawRoundRect(r, 8f, 8f, fill)
                stroke.color = col; stroke.strokeWidth = if (strong) 5f else 2f
                c.drawRoundRect(r, 8f, 8f, stroke)
                c.drawText("${k + 1}", x + cell / 2, y + cell / 2 + txt.textSize / 3, txt)
            }
            tray[m.slot]?.let { t ->
                var cy = t.top - cell * 0.35f
                if (cy < cell * 0.3f) cy = t.bottom + cell * 0.4f
                fill.color = col
                c.drawCircle(t.centerX(), cy, cell * (if (strong) 0.34f else 0.26f), fill)
                c.drawText("${k + 1}", t.centerX(), cy + txt.textSize / 3, txt)
            }
        }
    }
}

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private val ui = Handler(Looper.getMainLooper())
    private var thread: HandlerThread? = null
    private var bg: Handler? = null
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vd: VirtualDisplay? = null
    private var hints: HintsView? = null
    private var panel: View? = null
    private var toggle: TextView? = null
    private var status: TextView? = null
    @Volatile private var enabled = false
    @Volatile private var ratio = 0.6f
    private var sw = 0
    private var sh = 0
    private var pix: IntArray? = null
    private var frame: Frame? = null
    private var board: BoardRect? = null
    private var lastKey: String? = null
    private var pendingKey: String? = null
    private var hasPlan = false
    private var idle = 0

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) { stopSelf(); return START_NOT_STICKY }
        if (hints != null) return START_NOT_STICKY
        startFg()
        val code = intent.getIntExtra("code", 0)
        @Suppress("DEPRECATION")
        val data = intent.getParcelableExtra<Intent>("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(dm)
        sw = dm.widthPixels; sh = dm.heightPixels
        val t = HandlerThread("bh"); t.start(); thread = t; bg = Handler(t.looper)
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val p = mpm.getMediaProjection(code, data)
        projection = p
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { ui.post { stopSelf() } }
        }, ui)
        val rd = ImageReader.newInstance(sw, sh, PixelFormat.RGBA_8888, 2)
        reader = rd
        vd = p.createVirtualDisplay("bh", sw, sh, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, null, null, null)
        buildUi()
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("ov", "Overlay", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "ov")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("Block Helper")
            .setContentText("Оверлей работает")
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun tv(t: String, size: Float = 15f) = TextView(this).apply {
        text = t; setTextColor(Color.WHITE); textSize = size
        setPadding(dp(10), dp(6), dp(10), dp(6)); gravity = Gravity.CENTER
    }

    private fun pill(color: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(14).toFloat() }

    private fun buildUi() {
        val hv = HintsView(this); hints = hv
        val lp = WindowManager.LayoutParams(
            -1, -1, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        if (Build.VERSION.SDK_INT >= 28)
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        wm.addView(hv, lp)

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.background = pill(0xDD14141C.toInt())
        val grip = tv("≡", 20f)
        val tg = tv("ВЫКЛ"); tg.background = pill(0xFF8A2B2B.toInt()); toggle = tg
        val st = tv("—", 12f); status = st
        val minus = tv("−", 18f); val plus = tv("+", 18f); val close = tv("✕", 16f)
        for (v in listOf(grip, tg, st, minus, plus, close)) row.addView(v)
        panel = row

        val plp = WindowManager.LayoutParams(
            -2, -2, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        )
        plp.gravity = Gravity.TOP or Gravity.START; plp.x = dp(8); plp.y = dp(60)
        grip.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = plp.x; oy = plp.y }
                    MotionEvent.ACTION_MOVE -> {
                        plp.x = ox + (e.rawX - sx).toInt(); plp.y = oy + (e.rawY - sy).toInt()
                        wm.updateViewLayout(row, plp)
                    }
                }
                return true
            }
        })
        tg.setOnClickListener { setOn(!enabled) }
        minus.setOnClickListener { adjust(-0.03f) }
        plus.setOnClickListener { adjust(0.03f) }
        close.setOnClickListener { stopSelf() }
        wm.addView(row, plp)
    }

    private fun adjust(d: Float) {
        ratio = (ratio + d).coerceIn(0.35f, 0.9f)
        say("тray ${"%.2f".format(ratio)}")
        bg?.post { lastKey = null; pendingKey = null }
    }

    private fun say(s: String) { ui.post { status?.text = s } }

    private fun setOn(on: Boolean) {
        enabled = on
        toggle?.text = if (on) "ВКЛ" else "ВЫКЛ"
        toggle?.background = pill(if (on) 0xFF1F8A4C.toInt() else 0xFF8A2B2B.toInt())
        val b = bg ?: return
        if (on) {
            vd?.surface = reader?.surface
            b.post {
                board = null; lastKey = null; pendingKey = null; hasPlan = false; frame = null; idle = 0
                ui.post { hints?.plan = null; hints?.invalidate() }
                tick.run()
            }
        } else {
            b.removeCallbacks(tick)
            vd?.surface = null
            hasPlan = false
            hints?.plan = null; hints?.invalidate()
            say("—")
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!enabled) return
            try { step() } catch (e: Throwable) { say("ошибка") }
            if (enabled) bg?.postDelayed(this, 450)
        }
    }

    private fun grab(rd: ImageReader) {
        val img = rd.acquireLatestImage() ?: return
        try {
            val pl = img.planes[0]
            val buf = pl.buffer.order(ByteOrder.nativeOrder()).asIntBuffer()
            val stride = pl.rowStride / 4
            val arr = pix ?: IntArray(sw * sh).also { pix = it }
            for (y in 0 until sh) { buf.position(y * stride); buf.get(arr, y * sw, sw) }
            frame = Frame(sw, sh, arr)
        } finally { img.close() }
    }

    private fun step() {
        val rd = reader ?: return
        val hv = hints ?: return
        if (hasPlan) {
            rd.acquireLatestImage()?.close()
            ui.post { hv.visibility = View.INVISIBLE }
            Thread.sleep(200)
        }
        grab(rd)
        if (hasPlan) ui.post { hv.visibility = View.VISIBLE }
        val f = frame ?: return

        if (board == null) {
            board = Detector.findBoard(f)
            if (board == null) { say("поле?"); return }
        }
        val br = board!!
        val rdg = Detector.read(f, br, ratio)
        val present = BooleanArray(3) { rdg.pieces[it] != null }
        ui.post { hv.board = br; hv.present = present; hv.tray = rdg.tray; hv.invalidate() }
        val cnt = present.count { it }

        if (cnt == 3) {
            idle = 0
            val key = rdg.board.toString() + "|" + rdg.pieces.joinToString("|") { it!!.key }
            if (key != lastKey) {
                if (key == pendingKey) {
                    val t0 = System.currentTimeMillis()
                    val plan = Solver.solve(rdg.board, rdg.pieces.toList())
                    lastKey = key
                    hasPlan = plan != null
                    ui.post { hv.board = br; hv.plan = plan; hv.present = present; hv.tray = rdg.tray; hv.invalidate() }
                    say(if (plan == null) "нет ходов" else "ок ${System.currentTimeMillis() - t0}мс")
                } else pendingKey = key
            }
        } else if (!hasPlan) {
            say(if (cnt == 0) "жду фигуры" else "фигур: $cnt")
            if (++idle % 12 == 0) board = null
        }
    }

    override fun onDestroy() {
        enabled = false
        bg?.removeCallbacksAndMessages(null)
        try { hints?.let { wm.removeView(it) } } catch (e: Exception) {}
        try { panel?.let { wm.removeView(it) } } catch (e: Exception) {}
        try { vd?.release() } catch (e: Exception) {}
        try { reader?.close() } catch (e: Exception) {}
        try { projection?.stop() } catch (e: Exception) {}
        thread?.quitSafely()
        super.onDestroy()
    }
}
