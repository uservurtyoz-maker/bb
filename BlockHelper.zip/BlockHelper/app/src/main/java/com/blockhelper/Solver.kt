package com.blockhelper

import java.util.PriorityQueue

/** Фигура: список клеток (row, col), нормализованных к (0,0). */
class Shape(val cells: List<IntArray>) {
    val h = cells.maxOf { it[0] } + 1
    val w = cells.maxOf { it[1] } + 1
    val key: String = cells.sortedWith(compareBy<IntArray>({ it[0] }, { it[1] }))
        .joinToString(";") { "${it[0]},${it[1]}" }
    val masks: LongArray

    init {
        val l = ArrayList<Long>()
        if (h <= 8 && w <= 8) for (r in 0..8 - h) for (c in 0..8 - w) {
            var m = 0L
            for (x in cells) m = m or (1L shl ((r + x[0]) * 8 + c + x[1]))
            l.add(m)
        }
        masks = l.toLongArray()
    }
}

class Move(val slot: Int, val mask: Long, val burn: Long)
class Plan(val moves: List<Move>, val score: Double)
internal class Cand(
    val score: Double, val slots: IntArray, val masks: LongArray,
    val burns: LongArray, val n: Int, val fin: Long
)

object Solver {
    private val ROWS = LongArray(8) { 0xFFL shl (8 * it) }
    private val COLS = LongArray(8) { c ->
        var m = 0L
        for (r in 0 until 8) m = m or (1L shl (r * 8 + c))
        m
    }
    private val COL0 = 0x0101010101010101L
    private val COL7 = COL0 shl 7
    private val NOT_A = COL0.inv()
    private val NOT_H = COL7.inv()
    private val ROW0 = 0xFFL
    private val ROW7 = 0xFFL shl 56
    private val LOW56 = (1L shl 56) - 1

    private fun norm(c: List<IntArray>): List<IntArray> {
        val mr = c.minOf { it[0] }
        val mc = c.minOf { it[1] }
        return c.map { intArrayOf(it[0] - mr, it[1] - mc) }
    }
    private fun rot(c: List<IntArray>) = norm(c.map { intArrayOf(it[1], -it[0]) })
    private fun mir(c: List<IntArray>) = norm(c.map { intArrayOf(it[0], -it[1]) })
    private fun parse(rows: List<String>): List<IntArray> {
        val out = ArrayList<IntArray>()
        for ((r, s) in rows.withIndex()) for ((c, ch) in s.withIndex()) if (ch == 'X') out.add(intArrayOf(r, c))
        return out
    }

    /** Типовые фигуры игры (все повороты и отражения) для оценки «влезет ли что-то дальше». */
    private val STD: List<Shape> by lazy {
        val bases = listOf(
            listOf("X"), listOf("XX"), listOf("XXX"), listOf("XXXX"), listOf("XXXXX"),
            listOf("XX", "XX"), listOf("XXX", "XXX"), listOf("XXX", "XXX", "XXX"),
            listOf("X.", "XX"), listOf("X.", "X.", "XX"), listOf("X..", "X..", "XXX"),
            listOf(".X.", "XXX"), listOf("XX.", ".XX"), listOf("XX", "X.", "X.")
        )
        val map = LinkedHashMap<String, Shape>()
        for (b in bases) {
            var cur = parse(b)
            repeat(4) {
                for (v in listOf(cur, mir(cur))) { val s = Shape(v); map[s.key] = s }
                cur = rot(cur)
            }
        }
        map.values.toList()
    }

    private fun bc(x: Long) = java.lang.Long.bitCount(x)

    /** Быстрая оценка доски: меньше занято, меньше дыр и «рваности». */
    private fun cheap(b: Long): Double {
        val e = b.inv()
        val l = ((b shl 1) and NOT_A) or COL0
        val r = ((b ushr 1) and NOT_H) or COL7
        val u = (b shl 8) or ROW0
        val d = (b ushr 8) or ROW7
        val h4 = bc(e and l and r and u and d)
        val h3 = bc(e and ((l and r and u) or (l and r and d) or (l and u and d) or (r and u and d)))
        val trH = bc((b xor (b ushr 1)) and NOT_H)
        val trV = bc((b xor (b ushr 8)) and LOW56)
        return -bc(b) * 1.0 - h4 * 9.0 - h3 * 3.0 - (trH + trV) * 0.7
    }

    private fun fit(b: Long): Double {
        var n = 0
        for (s in STD) for (m in s.masks) if ((b and m) == 0L) { n++; break }
        return n * 1.0
    }

    private fun regions(b: Long): Double {
        val seen = BooleanArray(64)
        val st = IntArray(64)
        var pen = 0.0
        for (s in 0 until 64) {
            if (seen[s] || ((b ushr s) and 1L) == 1L) continue
            var sp = 0
            st[sp++] = s; seen[s] = true
            var size = 0
            while (sp > 0) {
                val i = st[--sp]; size++
                val r = i / 8; val c = i % 8
                if (c > 0 && !seen[i - 1] && ((b ushr (i - 1)) and 1L) == 0L) { seen[i - 1] = true; st[sp++] = i - 1 }
                if (c < 7 && !seen[i + 1] && ((b ushr (i + 1)) and 1L) == 0L) { seen[i + 1] = true; st[sp++] = i + 1 }
                if (r > 0 && !seen[i - 8] && ((b ushr (i - 8)) and 1L) == 0L) { seen[i - 8] = true; st[sp++] = i - 8 }
                if (r < 7 && !seen[i + 8] && ((b ushr (i + 8)) and 1L) == 0L) { seen[i + 8] = true; st[sp++] = i + 8 }
            }
            if (size < 5) pen += (5 - size) * 2.5
        }
        return pen
    }

    private fun perms(n: Int): List<IntArray> {
        val out = ArrayList<IntArray>()
        fun go(cur: List<Int>) {
            if (cur.size == n) { out.add(cur.toIntArray()); return }
            for (i in 0 until n) if (i !in cur) go(cur + i)
        }
        go(emptyList())
        return out
    }

    private fun offer(
        heap: PriorityQueue<Cand>, k: Int, b: Long, bonus: Double, n: Int,
        sl: IntArray, mk: LongArray, bn: LongArray
    ) {
        val s = bonus + cheap(b)
        if (heap.size >= k && s <= heap.peek()!!.score) return
        heap.add(Cand(s, sl.copyOf(), mk.copyOf(), bn.copyOf(), n, b))
        if (heap.size > k) heap.poll()
    }

    /** board: бит i = row*8+col занят. pieces: фигуры лотка слева направо (null = уже поставлена). */
    fun solve(board: Long, pieces: List<Shape?>): Plan? {
        val idx = pieces.indices.filter { pieces[it] != null }
        val n = idx.size
        if (n == 0) return null
        val shapes = idx.map { pieces[it]!! }
        val heap = PriorityQueue<Cand>(compareBy<Cand> { it.score })
        val sl = IntArray(3); val mk = LongArray(3); val bn = LongArray(3)

        for (order in perms(n)) {
            fun dfs(b: Long, d: Int, bonus: Double, prevClear: Boolean) {
                if (d == n) { offer(heap, 40, b, bonus, d, sl, mk, bn); return }
                val sh = shapes[order[d]]
                var any = false
                for (m in sh.masks) {
                    if ((b and m) != 0L) continue
                    any = true
                    var nb = b or m
                    var burn = 0L
                    var lines = 0
                    for (k in 0 until 8) {
                        if ((nb and ROWS[k]) == ROWS[k]) { burn = burn or ROWS[k]; lines++ }
                        if ((nb and COLS[k]) == COLS[k]) { burn = burn or COLS[k]; lines++ }
                    }
                    nb = nb and burn.inv()
                    sl[d] = idx[order[d]]; mk[d] = m; bn[d] = burn
                    val bo = bonus + lines * lines * 10.0 + (if (lines > 0 && prevClear) 12.0 else 0.0)
                    dfs(nb, d + 1, bo, lines > 0)
                }
                if (!any) offer(heap, 40, b, bonus - 1000.0 * (n - d), d, sl, mk, bn)
            }
            dfs(board, 0, 0.0, false)
        }

        var best: Cand? = null
        var bs = -1e18
        for (c in heap) {
            val s = c.score + fit(c.fin) - regions(c.fin)
            if (s > bs) { bs = s; best = c }
        }
        val b = best ?: return null
        return Plan((0 until b.n).map { Move(b.slots[it], b.masks[it], b.burns[it]) }, bs)
    }
}
